package com.example.soccer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
